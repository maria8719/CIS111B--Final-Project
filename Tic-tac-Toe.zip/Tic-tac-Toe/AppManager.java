import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

public class AppManager {
    
    static Menu menu = new Menu();
    static SinglePlayerPane singlePlayerPane = new SinglePlayerPane();
    static MultiPlayerPane multiPlayerPane = new MultiPlayerPane();
    static GameWindow gameWindow = new GameWindow();
    
    static String preferredBoard;

    static Font preferredFont;
    
    static boolean challengeComputer;
    
    public static void viewPane(Pane pane)
    {
        menu.setVisible(false);
        singlePlayerPane.setVisible(false);
        multiPlayerPane.setVisible(false);
        gameWindow.setVisible(false);
        
        pane.setVisible(true);
    }
   
    public static void setFont()
    {
        menu.singlePlayer.setFont(preferredFont);
        menu.multiPlayer.setFont(preferredFont);
        menu.exit.setFont(preferredFont);
        
        singlePlayerPane.playerNameLabel.setFont(preferredFont);
        singlePlayerPane.playerName.setFont(preferredFont);
        singlePlayerPane.start.setFont(preferredFont);
        singlePlayerPane.back.setFont(preferredFont);
        
        multiPlayerPane.playerXLabel.setFont(preferredFont);
        multiPlayerPane.playerOLabel.setFont(preferredFont);
        multiPlayerPane.firstPlayerName.setFont(preferredFont);
        multiPlayerPane.secondPlayerName.setFont(preferredFont);
        multiPlayerPane.start.setFont(preferredFont);
        multiPlayerPane.back.setFont(preferredFont);
        
        gameWindow.firstPlayerName.setFont(preferredFont);
        gameWindow.secondPlayerName.setFont(preferredFont);
        gameWindow.firstPlayerScore.setFont(preferredFont);
        gameWindow.secondPlayerScore.setFont(preferredFont);
        gameWindow.currentPlayerSymbol.setFont(preferredFont);
       // gamePane.restart.setFont(preferredFont);
        gameWindow.back.setFont(preferredFont);
        
             
    }
    
}
