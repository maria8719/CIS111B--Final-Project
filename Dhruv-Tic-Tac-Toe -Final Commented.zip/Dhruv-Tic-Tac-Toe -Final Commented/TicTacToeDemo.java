// Import classes from JavaAPI and JavaFx.
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.geometry.*;
import javafx.scene.paint.Color;
import java.nio.file.Paths;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.lang.Exception;
import javafx.application.Platform;

/**
*  The TicTacToeDemo class runs and demonstrates the full program
*/
public class TicTacToeDemo extends Application 
{

    private Image applicationIcon;  // Create Image object to display the TicTacToe icon.
    
    // Create a label to store icon.
    Label label = new Label(); 
   

    /**
    *  Main method to test the program.
    */
    public static void main(String[] args) 
    {
        // Launch the application.
        launch(args);
    }
 
    /**
    *  The start method creates the application window.
    *  @param primaryStage The window on which the content
    *                      is displayed.
    */
    @Override
    public void start(Stage primaryStage)throws Exception 
    {
       // Play music in the background.
       PlayMusic.music(); 

       /**
       *  Puts the application icon.
       */
       try
       { 
          
          applicationIcon = new Image(getClass().getResource("/images/icon.png").toExternalForm());
		   
          primaryStage.getIcons().add(applicationIcon);
       }
       
       catch(Exception ex)
       {
         System.out.println("Icon NOT FOUND!");
       } 
      
       /**
       *  Create a graphic (image) for the tic tac toe game.
       */
       try
       {
          // Create an Image object by passing the image location as an argument.
          Image img = new Image("/images/tictactoc.jpg");
          ImageView view = new ImageView(img);
          
          // Set the size of the image.
          view.setFitHeight(80);
          view.setPreserveRatio(true);
          label.setGraphic(view);
          label.relocate(70,500);
       }

       catch(Exception  ex)
       {
          System.out.println("tictactoc image NOT FOUND!");
       }
   
       /**
       *  Creating background color.
       */
       Color c = Color.rgb(176, 224, 230);
       BackgroundFill background_fill = new BackgroundFill(c,CornerRadii.EMPTY, Insets.EMPTY);
  
       /**
       *  Create Background.
       */
       Background background = new Background(background_fill);
      
       /**
       *  Create an object from the Pane class for all containers.
       */
       Pane root = new Pane();
        
       /** 
       *  Add all the containers made in every class to display them in the root window.
       */
       root.getChildren().add(WindowsSwitch.menu);
       root.getChildren().add(WindowsSwitch.onePlayerWind);
       root.getChildren().add(WindowsSwitch.twoPlayerWind);
       root.getChildren().add(WindowsSwitch.gameWindow);
       root.getChildren().add(label);
       root.setBackground(background);
       WindowsSwitch.viewPane(WindowsSwitch.menu);

       /**
       *  Create the program window where the containers are placed.
       */
       Scene scene = new Scene(root, 380, 600);
        
       // Set the stage title.
       primaryStage.setTitle("Tic Tac Toe Game");
       
       // Add scene to stage.
       primaryStage.setScene(scene);
       
       // Display the window.
       primaryStage.show();

         
     } // End of start method.
  
  /**
  *  The stop method stops the applicatio if an error occurs.
  */
  
  @Override
  public void stop() throws Exception 
  { 
    // Display the message that application has stopped.
    System.out.println("The Application Is STOPPED");
    Platform.exit();
    
    // Exit the application.
    System.exit(0);
    
  }
  
} // End of TicTacToeDemo class.
