// Import JavaFx classes.
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import javafx.scene.text.Font; 
import javafx.scene.text.FontPosture; 
import javafx.scene.text.FontWeight;


/**
   The TwoPlayerWind class creates the window for starting a two-player game.
*/

public class TwoPlayerWind extends Pane 
{

    /**
    *  Content to be placed in the window.
    */
    
    // Create a textfield to enter the name of player1.
    TextField playerName1 = new TextField("player Name (X)");
    
    // Create a texfield to enter the name of player2.
    TextField playerName2 = new TextField("player Name (O)");
    
    // Create a button to start the game.
    Button startButton = new Button("Start");
    
    // Create a button to go back in the game.
    Button backButton = new Button("Back");

    /**
    *  Create a no-arg constructor of TwoPlayerWind class.
    */
    public TwoPlayerWind() 
    {

        /**
        *  Adjust the size of the content.
        */
        playerName1.setPrefSize(240, 30);
        playerName2.setPrefSize(240, 30);
        startButton.setPrefSize(240, 40);
        backButton.setPrefSize(240, 40);
        
        /**
        *  Adjust the position of the content.
        */
        playerName1.setTranslateX(80);
        playerName1.setTranslateY(170);
        playerName2.setTranslateX(80);
        playerName2.setTranslateY(210);
        startButton.setTranslateX(80);
        startButton.setTranslateY(260);
        backButton.setTranslateX(80);
        backButton.setTranslateY(320);
        
        /**
        *  Set the font style of the content displayed.
        */
        backButton.setFont(Font.font("serif", FontWeight.BOLD, 16));  
        startButton.setFont(Font.font("serif", FontWeight.BOLD, 16)); 
        playerName1.setFont(Font.font("serif", FontWeight.BOLD, FontPosture.ITALIC, 16));  
        playerName2.setFont(Font.font("serif", FontWeight.BOLD, FontPosture.ITALIC, 16)); 
 
        /**
        *  Add the content to the container.
        */
        getChildren().add(playerName1);
        getChildren().add(playerName2);
        getChildren().add(startButton);
        getChildren().add(backButton);
        
        /**
        *  Define action for when the start button is clicked on.
        *  Action: Begin a two-player game.
        *  The names entered by the user are passed and inserted
        *  as playerName1 and playerName2 variables.
        */
        startButton.setOnAction((Action) -> {
         
            PlayMusic.mediaPlayer.stop();
            WindowsSwitch.gameWindow.playerName1.setText(playerName1.getText());
            WindowsSwitch.gameWindow.playerName2.setText(playerName2.getText());
            WindowsSwitch.gameWindow.playerScore1.setText("0");
            WindowsSwitch.gameWindow.playerScore2.setText("0");

            /**
            *  Pass a false variable for the boolean that indicates
            *  the player is not playing against the computer.
            */
            WindowsSwitch.againstComputer = false;
            
            /**
            *  Insert a background image for the board.
            */
            try
            {
               WindowsSwitch.gameWindow.gameBoardBackground.setImage(new Image(getClass().getResourceAsStream("/images/ticBackground.png")));
            }
          
            catch(Exception  ex)
            {
               System.out.println("ticBackground.png NOT FOUND!");
            } 
 
            /**
            *  Open the game window.
            */
            WindowsSwitch.viewPane(WindowsSwitch.gameWindow);
            
        });

        /**
           Define an action for when the back button is clicked on
           Action: Return to the main menu
        */
        backButton.setOnAction((event) -> {
        
            WindowsSwitch.viewPane(WindowsSwitch.menu);
            
        });
     
       
      /**
      *  Plays sound of typing the player1 name.
      */
		playerName1.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});
 
        
      /**
      *  Plays sound of typing the player1 name.
      */
		playerName2.textProperty().addListener(e -> {
      
			PlayMusic.typekMusic();

		});

    }  // End of TwoPlayerWind constructor.
    
}  // End of TwoPlayeWind class.
