// Import classes from Jfugue, JavaAPI, JavaFX.
import java.nio.file.Paths;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.media.MediaException;
import org.jfugue.player.Player;
import org.jfugue.rhythm.Rhythm;

/**
*  The PlayMusic class uses MediaPlayer to play music and sound for the game.
*/
public class PlayMusic
{          
   // MediaPlayer object to play background music.
   public static MediaPlayer mediaPlayer; 
   
   // MediaPlayer object to play sounds when different buttons are clicked.    
   public static MediaPlayer winSound, clickSound, GameOver, playAgainSound;  
                                                                              

   /**
   *  The music method plays background music when starting the game
   */
   public static void music() 
   {

      try
      {     
        // Pass the audio file location as argument to Media object.
        Media mainMenuSound = new Media(Paths.get("./sound/home.mp3").toUri().toString());
        
        // Pass the audio as argument to the MediaPlayer object.
		  mediaPlayer = new MediaPlayer(mainMenuSound);
        
        // Play the music.
		  mediaPlayer.play();    
      }
      
      catch(MediaException ex)
      {
        System.out.println("home.mp3 audio file NOT FOUND!");
      }   
        
   } // End of music method.

   /**
   *  The winMusic method plays sound music when the player wins the game.
   */
   public static void winMusic()
   {

      try
      {
         // Pass the audio file as an argument to the Media Player object.
         winSound = new MediaPlayer(new Media(Paths.get("./sound/win.wav").toUri().toString()));
         
         // Play the music.
         winSound.play();
      }
     
      catch(MediaException ex)
      {
         System.out.println("win.mp3 audio file NOT FOUND!");

      }
      
   }  // End of winMusic method.

   /**
   *  The GameOverMusic method plays sound music when the game is over without winners
   */
   public static void GameOverMusic()
   {

       try
       {
          // Pass the audio file as an argument to the MediaPlayer object
          GameOver = new MediaPlayer(new Media(Paths.get("./sound/gun.mp3").toUri().toString()));
          
          // Play the music.
          GameOver.play();
       }

       catch(MediaException ex)
       {
          System.out.println("gun.mp3 audio file NOT FOUND!");
       }

   }  // End of GameOver method.

   /**
   *  The typelMusic method plays sound while typing.
   */
   public static void typekMusic()
   {
 
      try
      { 
         // Pass the audio file as an argument to the MediaPlayer object.
         MediaPlayer md = new MediaPlayer(new Media(Paths.get("./sound/type.mp3").toUri().toString()));
         
         // Set the timing of the sound as 0 seconds when typing on keyboard.
         md.seek(Duration.ZERO);
         
         // Play the sound.
         md.play();
      }  
 
      catch(MediaException ex) 
      {
         System.out.println("type.mp3 audio file NOT FOUND!");
      }
  
   }  // End of typekMusic method.
   
   /**
   *  The clickMusic method plays sound when clicking mouse.
   */
   public static void clickMusic()
   {

      try
      {
         // Pass the audio file as an argument to MediaPlayer obejct.
         clickSound = new MediaPlayer(new Media(Paths.get("./sound/click.wav").toUri().toString()));
         
         // Play the sound when clicking with mouse.
         clickSound.play();
      }

      catch(MediaException ex)
      {
         System.out.println("click.mp3 audio file NOT FOUND!");
      }

   } // End of ClickMusic method.

   /**
   *  The playAgainMusic method plays the sound when PlayAgain button is pressed.
   */
   public static void playAgainMusic()
   {

      try
      {
         // Pass the audio file as an argument to the MediaPlayer object.
         playAgainSound = new MediaPlayer(new Media(Paths.get("./sound/gun.mp3").toUri().toString()));
         
         // Play the sound.
         playAgainSound.play();
      }

      catch(MediaException ex)
      {
         System.out.println("gun.mp3 audio file NOT FOUND!");
      }

   } // End of PlayAgainMusic method.

   /**
   *  The music2 metho
   */
   public static void music2() 
   {
        Rhythm rhythm = new Rhythm()
          .addLayer("O..oO...O..oOO..") // This is Layer 0
          .addLayer("..S...S...S...S.")
          .addLayer("````````````````")
          .addLayer("...............+") // This is Layer 3
          .addOneTimeAltLayer(3, 3, "...+...+...+...+") // Replace Layer 3 with this string on the 4th (count from 0) measure
          .setLength(4); // Set the length of the rhythm to 4 measures
        new Player().play(rhythm.getPattern().repeat(1)); // Play 2 instances of the 4-measure-long rhythm
   
   } //  End of music2 method. 


} // End of PayMusic class.
