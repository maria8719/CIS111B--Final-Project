// Import clasess from JavaAPI and JavaFX.
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import javafx.scene.text.Font; 
import javafx.scene.text.FontPosture; 
import javafx.scene.text.FontWeight; 

/**
*  The GameWindow class creates the game window that appears when the game is started
*  in each of the window Multi Player and Single Player. 
*/

public class GameWindow extends Pane 
{ 

    /**
    *  Create the content for the window.
    */
   
    // Create a label to type name of Player1.
    Label playerName1 = new Label();
    
    // Create a label to type name of Player2.
    Label playerName2 = new Label();
    
    // Create a label to show points for Player1.
    Label playerScore1 = new Label("0");
    
    // Create a label to show points for Player2.
    Label playerScore2 = new Label("0");
    
    // Create a label to show the symbol X or O.
    Label playerSymbol = new Label();
    
    // Create a label to show the winner of the game.
    Label winner = new Label();
    
    // Create the Game Board using the GridPane object.
	 GridPane gameBoardPane = new GridPane();
    
    // Create buttons to be clicked by the user to play.
    Button[] gameButtons = new Button[3*3];
    
    // Create a button to go back in the game.
    Button back = new Button("Back");
    
    // Create a button to give the option to play again.
    Button playAgain = new Button("Play Again");
    
    // Create a button to exit the game.
    Button exit = new Button("Exit");
    
    // Create the outliine of the game board.
    ImageView gameBoardBackground = new ImageView();
    
    // Creat a Random object.
    Random random = new Random();

    /**
    *  The gameEnds boolean determines when game is over after a player wins.
    */
    private boolean gameEnds; 
   
    private boolean tie = false;
    private boolean win = false;
   
    /**
    *  Determine whose turn it is at the moment.
    */
    private boolean player1Turn = true; 
        
    /**
    *  Count the number of clicks and decide whether or not to stop the game.
    */
    private int OXCounter = 0, number;    
   
    /**
    *  Represents the default colors used for the color icons X and O.
    */
    Color XForeground = Color.YELLOW;
    Color OForeground = Color.GREEN;

    /**    
    *  Strings represent the text that display the name of the winner.
    */   
    private String text1, text2;
 
    /**
    *  Create a no-arg constructor for GameWindow class. 
    */
   
    public GameWindow() 
    {
        /**
        *  Adjust size of the content displayed.
        */
        playerName1.setPrefSize(150, 30);
        playerName2.setPrefSize(150, 30);
        playerScore1.setPrefSize(150, 30);
        playerScore2.setPrefSize(150, 30);
        playerSymbol.setPrefSize(150, 30);
        gameBoardPane.setPrefSize(300, 300);
        playAgain.setPrefSize(140, 30);
        exit.setPrefSize(100, 30);
        //winner.setPrefSize(320, 5);

        /**
        *  Adjust position of the content displayed.
        */
        playerName1.setTranslateY(10);
        playerName2.setTranslateX(250);
        playerName2.setTranslateY(10);
        playerScore1.setTranslateY(40);
        playerScore2.setTranslateX(250);
        playerScore2.setTranslateY(40);
        playerSymbol.setTranslateX(120);
        playerSymbol.setTranslateY(25);
        gameBoardBackground.setFitWidth(300);
        gameBoardBackground.setFitHeight(300);
        gameBoardBackground.setTranslateX(45);
        gameBoardBackground.setTranslateY(105);
        gameBoardPane.setTranslateX(45);
        gameBoardPane.setTranslateY(105);
        back.setPrefSize(100, 30);
        back.setTranslateX(20);
        back.setTranslateY(455);
        playAgain.setTranslateX(123);
        playAgain.setTranslateY(455);
        exit.setTranslateX(270);
        exit.setTranslateY(455);
        winner.setTranslateX(40);
		  winner.setTranslateY(420);
       
        /**
        *  Set the font style of the content displayed.
        */        
        exit.setFont(Font.font("serif", FontWeight.BOLD, 16)); 
        back.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playAgain.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playerName1.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playerName2.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playerSymbol.setFont(Font.font("serif", FontWeight.BOLD, 16));
        winner.setFont(Font.font("serif", FontWeight.BOLD, 10)); 

        /**
        *  Align text in the center of the space reserved for them.
        */
        playerName1.setAlignment(Pos.CENTER);
        playerName2.setAlignment(Pos.CENTER);
        playerScore1.setAlignment(Pos.CENTER);
        playerScore2.setAlignment(Pos.CENTER);
        playerSymbol.setAlignment(Pos.CENTER);
        

        /**
        *  Create the game board.
        */
        gameBoard();
        
        /**
        *  Add content to the container.
        */
        getChildren().add(playerName1);
        getChildren().add(playerName2);
        getChildren().add(playerScore1);
        getChildren().add(playerScore2);
        getChildren().add(playerSymbol);
        getChildren().add(gameBoardPane);
        getChildren().add(gameBoardBackground);
        getChildren().add(back);
        getChildren().add(exit);
        getChildren().add(playAgain);
        getChildren().add(winner);
     
        /**
        *  Call the newGame method to begin a new game.
        */
        newGame();
        
        /**
        *  Define what happens when you click the back button .
        *  Action: Return to the previous menu and start a new one or two-player game.
        */
        back.setOnAction((Event) -> {

            newGame();
            
            if (WindowsSwitch.againstComputer)
                WindowsSwitch.viewPane(WindowsSwitch.onePlayerWind);
            
            else
                WindowsSwitch.viewPane(WindowsSwitch.twoPlayerWind);
            
        });
        
        /**
        *  Define what happens when you click the play again button.
        *  Action: Begin a new game with the same settings.
        */
        playAgain.setOnAction((Event) -> {
        
            PlayMusic.playAgainMusic();
            newGame();
            
        });
        
        /**
        *  Define what happens when you click the exit button.
        *  Action: Close the program.
        */
        
        exit.setOnAction((Action) -> {

            System.exit(0); 
                       
        });
        
    }  // End of GameWindow constructor.
  
    /**
    *  EventHandler to trigger a buttonClicked event when a button is pressed.
    */
    EventHandler<ActionEvent> eventHandler = (ActionEvent event) -> {
       
        buttonClicked(event);
        
    };

    /**
    *  The winnerBackground method color the background of the squares
    *  that the player won with gray color.
    *  @param button1 The button to be colored gray.
    *  @param button2 The button to be colored gray.
    *  @param button3 The button to be colored gray. 
    */    
    private void winnerBackground(Button button1, Button button2, Button button3)
    {
        button1.setStyle("-fx-background-color: Gray;");
        button2.setStyle("-fx-background-color: Gray;");
        button3.setStyle("-fx-background-color: Gray;");
    }
    
    /**
    *  The gameBoard method creates a game board with clickable
    *  spaces to place symbols.
    */
    private void gameBoard() 
    {    
        int row = 0;     // Holds the number of row.
        int column = 0;  // Holds the number of columns.
        
        // Perform interation to create the game board.
        for (int i = 0; i < gameButtons.length; i++) 
        {
            gameButtons[i] = new Button();

            gameButtons[i].setPrefSize(90, 90);
            gameButtons[i].setFocusTraversable(false);

            GridPane.setMargin(gameButtons[i], new Insets(5));
            gameButtons[i].setFont(Font.font("verdana", FontWeight.BOLD, 40));

            gameBoardPane.add(gameButtons[i], column, row);

            gameButtons[i].addEventHandler(ActionEvent.ACTION, e -> {
                
                buttonClicked(e);
            });
                
            column++;
            if(column == 3)
            {
                row++;
                column = 0;
            }
         }
        
    } // End of GameBoard method.
    
    /**
    *  The checkIfGameEnds method runs a check after every time players play to determine if the
    *  game has been won or not. Color the background of the squares that caused the player winning
    *  by calling the winnerBackground method. If there is a winner, the gameEnds will set to true 
    *  to stop the game and the Score variable we will be changed.   
    */
    private void checkIfGameEnds() 
    {   
        /**
        *  Convert the symbols from all the buttons to String data type in 
        *  order to compare the symbols.
        */
        String button00 = gameButtons[0].getText();
        String button01 = gameButtons[1].getText();
        String button02 = gameButtons[2].getText();
        String button03 = gameButtons[3].getText();
        String button04 = gameButtons[4].getText();
        String button05 = gameButtons[5].getText();
        String button06=  gameButtons[6].getText();
        String button07 = gameButtons[7].getText();
        String button08 = gameButtons[8].getText();
      
        // Compare each button using if statements and play winning music if a player wins.
        if (button00.equals(button01) && button00.equals(button02) && !button00.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[0], gameButtons[1], gameButtons[2]);
            PlayMusic.winMusic();
        }
 
        if (button03.equals(button04) && button03.equals(button05) && !button03.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[3], gameButtons[4], gameButtons[5]);
            PlayMusic.winMusic();
        }
 
        if (button06.equals(button07) && button06.equals(button08) && !button06.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[6], gameButtons[7], gameButtons[8]);
            PlayMusic.winMusic();
        }
 
        if (button00.equals(button03) && button00.equals(button06) && !button00.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[0], gameButtons[3], gameButtons[6]);
            PlayMusic.winMusic();
        }
 
        if (button01.equals(button04) && button01.equals(button07) && !button01.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[1], gameButtons[4], gameButtons[7]);
            PlayMusic.winMusic();
        }
 
        if (button02.equals(button05) && button02.equals(button08) && !button02.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[2], gameButtons[5], gameButtons[8]);
            PlayMusic.winMusic();
        }
 
        if (button00.equals(button04) && button00.equals(button08) && !button00.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[0], gameButtons[4], gameButtons[8]);
            PlayMusic.winMusic();
        }
 
        if (button02.equals(button04) && button02.equals(button06) && !button02.equals("")) 
        {
            gameEnds = true;
            win = true;
            winnerBackground(gameButtons[2], gameButtons[4], gameButtons[6]);
            PlayMusic.winMusic();
        }
        
        /** 
        *  Condition for a Tie game.
        */          
        if( OXCounter >= 9 && win== false) 
        {
                        
            gameEnds = true;
            tie = true;
            player1Turn = true;
            OXCounter = 0;
                    
       }

        /**
        *  Display a win message for the player that won the game.
        */
        if(gameEnds == true)   
        {
       
              if(player1Turn)
              {
                playerScore1.setText(Integer.valueOf(playerScore1.getText()) + 1 + "");
                text1= playerName1.getText() + " WON";
                winner.setText(text1);
                winner.setFont(Font.font("serif", FontWeight.BOLD, 20)); 
                winner.setTextFill(Color.web("#FF0000"));
                // winner.setRotate(20);                                               
              }
              else
              {
                playerScore2.setText(Integer.valueOf(playerScore2.getText()) + 1 + "");
                text2= playerName2.getText() + " WON";
                winner.setText(text2);
                winner.setFont(Font.font("serif", FontWeight.BOLD, 20)); 
                winner.setTextFill(Color.web("#FF0000"));
                //winner.setRotate(20);
              }                         
                          
            OXCounter = 0;
            playAgain.requestFocus();
            
        }
           
    }  // End of CheckIfGameEnds method.         
   
    /**
    *  The newGame method resets the board of Xs and Os when starting a new
    *  game and determine who goes first next game.
    */
    
    private void newGame() 
    {
        gameEnds = false;
         setCurrentSymbol();
        
        // Clear all the buttons.
        for (Button boardbuttons : gameButtons) 
        {
            boardbuttons.setText("");
            winner.setText("");
            
            boardbuttons.setStyle("-fx-background-color: none; -fx-cursor: hand;");
        }

    }  // End of newGame method.

 
   /**
   *  The setCurrentSymbol method determines whose turn it is and whose symbol 
   *  will be placed on click.
   */
   private void setCurrentSymbol() 
   {
        // If it is player1 then place 'X' symbol or else place 'O' symbol.
        if (player1Turn == true) 
        {
            playerSymbol.setText("X");
            playerSymbol.setTextFill(XForeground);
        } 
        else 
        {
            playerSymbol.setText("O");
            playerSymbol.setTextFill(OForeground);
        }
        
    }  // End of setCurrentSymbol method.

    /**
    *  Define what happens when any space on the game board is clicked.
    *  @param e The event that is going to occur.
    */
    private void buttonClicked(ActionEvent e)
    {
        /**
        *  Store the clicked space here.
        */
        Button clickedButton = (Button) e.getSource();
 
        /**
        *  On click, place an X or O in the space, but only if the game
        *  is not yet finished and the space is already empty.
        */
        if( gameEnds == false && clickedButton.getText().equals("") )
        {
            /**
            *  In a two-player game, the current player's symbol is placed in that space.
            */
            if(WindowsSwitch.againstComputer == false)
            {
                if(player1Turn) 
                {
                    clickedButton.setTextFill(XForeground);
                    clickedButton.setText("X");
                    PlayMusic.clickMusic();
                }
                else 
                {
                    clickedButton.setTextFill(OForeground);
                    clickedButton.setText("O");
                    PlayMusic.clickMusic();
                }
 
                /**
                *  Check if the first player won. If not, the next player gets their turn.
                */
                checkIfGameEnds();
                setCurrentSymbol();
                player1Turn = !player1Turn;
                setCurrentSymbol();
            }

            /**
            *  Check if the game is single-player against the computer.
            */
            if (WindowsSwitch.againstComputer == true)
            {
                /**
                *  Add an X to the space clicked on and check if it ends the game or not.
                */
                OXCounter++;
                player1Turn = true;
                clickedButton.setTextFill(XForeground);
                clickedButton.setText("X");
                PlayMusic.clickMusic();
                checkIfGameEnds();
 
                /**
                *  If the game is not over, the computer takes its turn next.
                */
                if(gameEnds == false)
                {
                    /**
                    *  Make the spaces temporarily unclickable so the player cannot 
                    *  move until the computer takes its turn.
                    */
                    for (Button boardButton : gameButtons) 
                    {
                        boardButton.removeEventHandler(ActionEvent.ACTION, eventHandler);
                    }

                    /**
                    *  The computer will place an 'O' in a random empty space.
                    */
                    OXCounter++;
                    player1Turn = false;
                    
                    for (Button boardButton : gameButtons) 
                    {
                        number = random.nextInt(9);
                        
                        if (gameButtons[number].getText().equals(""))
                        {
                            gameButtons[number].setTextFill(OForeground);
                            gameButtons[number].setText("O");
                            PlayMusic.clickMusic();
                            break;
                        }
                    }
                    
                    checkIfGameEnds(); 

                    /**
                    *  Check if the computer's move wins the game After the computer's 
                    *  turn, make the spaces clickable again for the player.
                    */
                    for (Button boardButton : gameButtons) 
                    {
                        boardButton.addEventHandler(ActionEvent.ACTION, eventHandler);
                    }
                    
                }
                
            }
    
        } 
        
    } // End of ButtonClick method.
    
} // End of GameWindow class.
   

