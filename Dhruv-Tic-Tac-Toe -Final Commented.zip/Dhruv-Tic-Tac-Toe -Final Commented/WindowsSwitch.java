// Import JavaFX classes.
import javafx.scene.layout.Pane;
import javafx.scene.text.*;
import javafx.scene.text.FontWeight;

/**
*  The WindowSwitch class is used to pass shared values while switching from window to window.
*/
public class WindowsSwitch 
{
    /**
    *  Create an object for the other classes that represents their respective windows.
    */
    
    static Menu menu = new Menu();                             // Create a Menu object.
    static OnePlayerWind onePlayerWind = new OnePlayerWind();  // Create a OnePlayerWind object.
    static TwoPlayerWind twoPlayerWind = new TwoPlayerWind();  // Create a TwoPlayerWind object.
    static GameWindow gameWindow = new GameWindow();           // Create a GameWindow object.
    
    /**
    *  This variable indicates whether the game is single-player against 
    *  a computer-controlled opponent.
    */
    static boolean againstComputer;
   
    /**
    *  The viewPane method shows only the window the user has opened and 
    *  hide the others until necessary.
    *  @param pane The Pane object.
    */
    public static void viewPane(Pane pane)
    {
        menu.setVisible(false);
        onePlayerWind.setVisible(false);
        twoPlayerWind.setVisible(false);
        gameWindow.setVisible(false);
        pane.setVisible(true);
    
    } // End of viewPane method.
   
} // End of WindowSwitch Class.
