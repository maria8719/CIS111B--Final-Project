import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

/**This class creates the window that first appears when the program starts*/
public class Menu extends Pane {
   /**Content to be placed inside the window*/
    Button OnePlayer = new Button("One Player");
    Button TwoPlayers = new Button("Two Players");  
    Button exit = new Button("Exit");

   /**Create the class container*/
    public Menu() {
      /**Adjust the size of the contents*/
        OnePlayer.setPrefSize(240, 40);
        TwoPlayers.setPrefSize(240, 40);
        exit.setPrefSize(240, 40);
      /**Adjust the position of the contents*/
        OnePlayer.setTranslateX(80);
        OnePlayer.setTranslateY(170);
        TwoPlayers.setTranslateX(80);
        TwoPlayers.setTranslateY(230);
        exit.setTranslateX(80);
        exit.setTranslateY(290);
      /**Insert content into the window*/
        getChildren().add(OnePlayer);
        getChildren().add(TwoPlayers);
        getChildren().add(exit);
      /**Define an action for the OnePlayer button when clicked on
      Action: Open to a single-player game*/
        OnePlayer.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.onePlayerWind);
        });
      /**Define an action for the TwoPlayer button when clicked on
      Action: Open to a two-player game*/
        TwoPlayers.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.twoPlayerWind);
        });

       
       /**Define an action for the exit button when clicked on
       Action: Close the program*/
        exit.setOnAction((event) -> {
            System.exit(0);
        });
    }

}
