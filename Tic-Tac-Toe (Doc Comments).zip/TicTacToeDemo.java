import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.geometry.*;
import javafx.scene.paint.Color;
import java.nio.file.Paths;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;

/**This test class runs and demonstrates the full program*/
public class TicTacToeDemo extends Application {

    private Image applicationIcon;
    private MediaPlayer mediaPlayer;

    /**Main method to test the program*/
    public static void main(String[] args) {
    
        launch(args);
    }
 
    @Override
    public void start(Stage primaryStage)throws Exception {
       
       PlayMusic.music(); 
   /*Puts the application icon*/
		
      applicationIcon = new Image(getClass().getResource("/images/icon.png").toExternalForm());
		primaryStage.getIcons().add(applicationIcon);
            
        /**Creating a Label*/
      Label label = new Label();
      /**Creating a graphic (image)*/
      Image img = new Image("tictactoc.jpg");
      ImageView view = new ImageView(img);
      view.setFitHeight(80);
      view.setPreserveRatio(true);
      label.setGraphic(view);
      label.relocate(70,500);
      
      /**Creating background color*/
      
      Color c = Color.rgb(176, 224, 230);
      BackgroundFill background_fill = new BackgroundFill(c,CornerRadii.EMPTY, Insets.EMPTY);
  
       /**Create Background*/
       Background background = new Background(background_fill);
      
       /**Create an object from the Pane class for all containers*/
        Pane root = new Pane();
        /**Add all the containers made in every class to display them in the root window*/
        root.getChildren().add(WindowsSwitch.menu);
        root.getChildren().add(WindowsSwitch.onePlayerWind);
        root.getChildren().add(WindowsSwitch.twoPlayerWind);
        root.getChildren().add(WindowsSwitch.gameWindow);
        root.getChildren().add(label);
        root.setBackground(background);
        WindowsSwitch.viewPane(WindowsSwitch.menu);
         /**Create the program window where the containers are placed*/
        Scene scene = new Scene(root, 380, 600);
        
        primaryStage.setTitle("Tic Tac Toe Game");
        primaryStage.setScene(scene);
         primaryStage.show();
         
          }

  
	}
