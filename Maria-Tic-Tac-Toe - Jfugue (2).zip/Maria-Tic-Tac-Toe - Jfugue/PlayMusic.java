import java.nio.file.Paths;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.media.MediaException;
import org.jfugue.player.Player;
import org.jfugue.rhythm.Rhythm;
import org.jfugue.player.ManagedPlayer;
/**
*****************************************************************
This class uses MediaPlayer to play music and sound for the game
*****************************************************************
*/
public class PlayMusic{           

public static MediaPlayer mediaPlayer;
public static MediaPlayer winSound, clickSound, GameOver, playAgainSound;

/**
********************************************
Play background music when starting the game
********************************************
*/
public static void music() {

 try{     		
      Media mainMenuSound = new Media(Paths.get("./sound/home.mp3").toUri().toString());
		mediaPlayer = new MediaPlayer(mainMenuSound);
		mediaPlayer.play(); 
    }
 catch(MediaException ex)
 {
 System.out.println("home.mp3 audio file NOT FOUND!");
 }   
        
   }

/**
********************************************
Play sound music when the player wins the game
********************************************
*/
public static void winMusic(){

try{

winSound = new MediaPlayer(new Media(Paths.get("./sound/win.wav").toUri().toString()));
winSound.play();
}

catch(MediaException ex)
{
 System.out.println("win.mp3 audio file NOT FOUND!");

}
}
/**
******************************************************
Play sound music when the game is over without winners
******************************************************
*/
public static void GameOverMusic(){

try{
GameOver = new MediaPlayer(new Media(Paths.get("./sound/gun.mp3").toUri().toString()));
GameOver.play();
}

catch(MediaException ex)
{
 System.out.println("gun.mp3 audio file NOT FOUND!");
}

}
/**
************************
Play sound while typing
************************
*/
public static void typekMusic(){
 
 try{
 
 MediaPlayer md = new MediaPlayer(new Media(Paths.get("./sound/type.mp3").toUri().toString()));
 md.seek(Duration.ZERO);
 md.play();
 }  
 catch(MediaException ex)
{
 System.out.println("type.mp3 audio file NOT FOUND!");
}
  
}		
/**
******************************
Play sound when clicking mouse
******************************
*/
public static void clickMusic(){

try{

clickSound = new MediaPlayer(new Media(Paths.get("./sound/click.wav").toUri().toString()));
clickSound.play();
}
catch(MediaException ex)
{
 System.out.println("click.mp3 audio file NOT FOUND!");
}

}

public static void playAgainMusic(){

try{
playAgainSound = new MediaPlayer(new Media(Paths.get("./sound/gun.mp3").toUri().toString()));
playAgainSound.play();
}

catch(MediaException ex)
{
 System.out.println("gun.mp3 audio file NOT FOUND!");
}

}

public static void music2() {

        Rhythm rhythm = new Rhythm()
          .addLayer("O..oO...O..oOO..") // This is Layer 0
          .addLayer("..S...S...S...S.")
          .addLayer("````````````````")
          .addLayer("...............+") // This is Layer 3
          .addOneTimeAltLayer(3, 3, "...+...+...+...+") // Replace Layer 3 with this string on the 4th (count from 0) measure
          .setLength(4); // Set the length of the rhythm to 4 measures
        new Player().play(rhythm.getPattern().repeat(1)); // Play 2 instances of the 4-measure-long rhythm
    }

}
