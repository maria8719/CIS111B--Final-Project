import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;

public class MultiPlayerPane extends Pane 
{

    Label playerXLabel = new Label("Player X");
    Label playerOLabel = new Label("Player O");
    TextField firstPlayerName = new TextField("player 1");
    TextField secondPlayerName = new TextField("player 2");
    Button start = new Button("Start");
    Button back = new Button("Back");

    public MultiPlayerPane() 
    {
     
     try{

        playerXLabel.setPrefSize(70, 30);
        firstPlayerName.setPrefSize(160, 30);
        playerOLabel.setPrefSize(70, 30);
        secondPlayerName.setPrefSize(160, 30);
        start.setPrefSize(240, 40);
        back.setPrefSize(240, 40);

        playerXLabel.setTranslateX(80);
        playerXLabel.setTranslateY(130);
        firstPlayerName.setTranslateX(160);
        firstPlayerName.setTranslateY(130);
        playerOLabel.setTranslateX(80);
        playerOLabel.setTranslateY(190);
        secondPlayerName.setTranslateX(160);
        secondPlayerName.setTranslateY(190);
        start.setTranslateX(80);
        start.setTranslateY(250);
        back.setTranslateX(80);
        back.setTranslateY(310);
        
        getChildren().add(playerXLabel);
        getChildren().add(playerOLabel);
        getChildren().add(firstPlayerName);
        getChildren().add(secondPlayerName);
        getChildren().add(start);
        getChildren().add(back);

        start.setOnAction((Action) -> {
            AppManager.gameWindow.firstPlayerName.setText(firstPlayerName.getText());
            AppManager.gameWindow.secondPlayerName.setText(secondPlayerName.getText());
            AppManager.gameWindow.firstPlayerScore.setText("0");
            AppManager.gameWindow.secondPlayerScore.setText("0");

            AppManager.challengeComputer = false;
            
            AppManager.gameWindow.boardBackground
                 .setImage(new Image(getClass().getResourceAsStream("/images/board_1.png")));
            
            AppManager.viewPane(AppManager.gameWindow);
        });
        
        back.setOnAction((event) -> {
            AppManager.viewPane(AppManager.menu);
        });
        
       }
       
       catch (Exception e)
       {
          System.out.println(e.getMessage());
       }
           
    }
    
}
