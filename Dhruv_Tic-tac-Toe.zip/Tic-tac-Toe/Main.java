import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;



public class Main extends Application 
{
    MediaPlayer mediaplayer;

    public static void main(String[] args) 
    {
        launch(args);
    }
 
    @Override
    public void start(Stage primaryStage)
    {
      try
      {
        // Create a Music file.
        Media musicFile = new Media("file_example_MP3_700KB.mp3");
        
        mediaplayer = new MediaPlayer(musicFile);
        
        // Play the music.
        mediaplayer.setAutoPlay(true);
        
        
        //Creating a Label
        Label label = new Label();
        
        //Creating a graphic (image)
        Image img = new Image("tictactoc.jpg");
        ImageView view = new ImageView(img);
        view.setFitHeight(80);
        view.setPreserveRatio(true);
        label.setGraphic(view);
        label.relocate(70,500);
        
                
        Pane root = new Pane();
        
        root.getChildren().add(AppManager.menu);
        root.getChildren().add(AppManager.singlePlayerPane);
        root.getChildren().add(AppManager.multiPlayerPane);
        root.getChildren().add(AppManager.gameWindow);
        root.getChildren().add(label);

        AppManager.viewPane(AppManager.menu);

        Scene scene = new Scene(root, 380, 600, Color.BEIGE);
        
        primaryStage.setTitle("Tic Tac Toe Game");
        
        primaryStage.setScene(scene);
        //primaryStage.setResizable(false);
        primaryStage.show();
            
      }
      
      catch (Exception e)
      {
         System.out.println(e.getMessage());
      }
           
    }
    
   
}
