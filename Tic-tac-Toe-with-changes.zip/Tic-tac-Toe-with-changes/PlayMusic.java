import java.nio.file.Paths;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;


public class PlayMusic{             

public static MediaPlayer mediaPlayer;
public static MediaPlayer winSound, clickSound, lostSound;

public static void music() {
      		
      Media mainMenuSound = new Media(Paths.get("home.mp3").toUri().toString());
		mediaPlayer = new MediaPlayer(mainMenuSound);
		mediaPlayer.play(); 
        
   }

public static void winMusic(){

winSound = new MediaPlayer(new Media(Paths.get("win.wav").toUri().toString()));

winSound.play();

}
public static void GameOverMusic(){

lostSound = new MediaPlayer(new Media(Paths.get("gun.mp3").toUri().toString()));


lostSound.play();

}
public static void typekMusic(){
 
 MediaPlayer md = new MediaPlayer(new Media(Paths.get("type.mp3").toUri().toString()));
 
   
       // Plays sound textField1
			md.seek(Duration.ZERO);
			md.play();
		
 
        
		// Plays sound textField2
		md.seek(Duration.ZERO);
		md.play();
}		
public static void clickMusic(){

clickSound = new MediaPlayer(new Media(Paths.get("click.wav").toUri().toString()));
clickSound.play();



}
}
