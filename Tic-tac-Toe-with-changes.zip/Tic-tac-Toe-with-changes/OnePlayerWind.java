import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import java.nio.file.Paths;

public class OnePlayerWind extends Pane {
    
    TextField playerNameTextField = new TextField("Player Name");
    Button startButton = new Button("Start");
    Button backButton = new Button("Back");
    Button exitButton = new Button("Exit");
 
    
    
         public OnePlayerWind() {
        
           		        
        playerNameTextField.setPrefSize(240, 30);
        startButton.setPrefSize(240, 40);
        backButton.setPrefSize(240, 40);

        playerNameTextField.setTranslateX(80);
        playerNameTextField.setTranslateY(170);
        startButton.setTranslateX(80);
        startButton.setTranslateY(220);
        backButton.setTranslateX(80);
        backButton.setTranslateY(280);

       
        getChildren().add(playerNameTextField);
        getChildren().add(startButton);
        getChildren().add(backButton);
        
       
       // Plays sound playerNameTextField
		playerNameTextField.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});

        
        startButton.setOnAction((event) -> {
            
            PlayMusic.mediaPlayer.stop();
            WindowsSwitch.gameWindow.playerName1.setText(playerNameTextField.getText());
            WindowsSwitch.gameWindow.playerName2.setText("Computer");
            WindowsSwitch.gameWindow.playerScore1.setText("0");
            WindowsSwitch.gameWindow.playerScore2.setText("0");

            WindowsSwitch.againstComputer = true;
           WindowsSwitch.gameWindow.gameBoardBackground.setImage(new Image(getClass().getResourceAsStream("/images/ticBackground.png")));
          

            WindowsSwitch.viewPane(WindowsSwitch.gameWindow);
        }
        
        );

        backButton.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.menu);
            
        }
        );
        
       }
}