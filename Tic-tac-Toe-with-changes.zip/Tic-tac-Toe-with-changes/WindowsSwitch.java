import javafx.scene.layout.Pane;


public class WindowsSwitch {
    
    static Menu menu = new Menu();
    static OnePlayerWind onePlayerWind = new OnePlayerWind();
    static TwoPlayerWind twoPlayerWind = new TwoPlayerWind();
    static GameWindow gameWindow = new GameWindow();
    
           
    static boolean againstComputer;
    
    public static void viewPane(Pane pane)
    {
        menu.setVisible(false);
        onePlayerWind.setVisible(false);
        twoPlayerWind.setVisible(false);
        gameWindow.setVisible(false);
        pane.setVisible(true);
    }
   
   
}
