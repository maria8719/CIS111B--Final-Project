import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class TwoPlayerWind extends Pane {

    TextField playerName1 = new TextField("player Name (X)");
    TextField playerName2 = new TextField("player Name (O)");
    Button startButton = new Button("Start");
    Button backButton = new Button("Back");

    public TwoPlayerWind() {

       
        playerName1.setPrefSize(240, 30);
        playerName2.setPrefSize(240, 30);
        startButton.setPrefSize(240, 40);
        backButton.setPrefSize(240, 40);

        playerName1.setTranslateX(80);
        playerName1.setTranslateY(170);
        playerName2.setTranslateX(80);
        playerName2.setTranslateY(210);
        startButton.setTranslateX(80);
        startButton.setTranslateY(260);
        backButton.setTranslateX(80);
        backButton.setTranslateY(320);
        
        
        getChildren().add(playerName1);
        getChildren().add(playerName2);
        getChildren().add(startButton);
        getChildren().add(backButton);

        startButton.setOnAction((Action) -> {
        PlayMusic.mediaPlayer.stop();
            WindowsSwitch.gameWindow.playerName1.setText(playerName1.getText());
            WindowsSwitch.gameWindow.playerName2.setText(playerName2.getText());
            WindowsSwitch.gameWindow.playerScore1.setText("0");
            WindowsSwitch.gameWindow.playerScore2.setText("0");

            WindowsSwitch.againstComputer = false;
            
           WindowsSwitch.gameWindow.gameBoardBackground
                 .setImage(new Image(getClass().getResourceAsStream("/images/ticBackground.png")));
            
            WindowsSwitch.viewPane(WindowsSwitch.gameWindow);
        });
        
        backButton.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.menu);
        });
     
       
      // Plays sound playerName1
		playerName1.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});
 
        
		// Plays sound playerName2
		playerName2.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});

    }
    
}
