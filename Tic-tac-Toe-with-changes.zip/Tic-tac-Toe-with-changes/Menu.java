import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class Menu extends Pane {

    Button OnePlayer = new Button("One Player");
    Button TwoPlayers = new Button("Two Players");  
    Button exit = new Button("Exit");


    public Menu() {

        OnePlayer.setPrefSize(240, 40);
        TwoPlayers.setPrefSize(240, 40);
        exit.setPrefSize(240, 40);

        OnePlayer.setTranslateX(80);
        OnePlayer.setTranslateY(170);
        TwoPlayers.setTranslateX(80);
        TwoPlayers.setTranslateY(230);
        exit.setTranslateX(80);
        exit.setTranslateY(290);

        getChildren().add(OnePlayer);
        getChildren().add(TwoPlayers);
        getChildren().add(exit);

        OnePlayer.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.onePlayerWind);
        });

        TwoPlayers.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.twoPlayerWind);
        });

       
       
        exit.setOnAction((event) -> {
            System.exit(0);
        });
    }

}
