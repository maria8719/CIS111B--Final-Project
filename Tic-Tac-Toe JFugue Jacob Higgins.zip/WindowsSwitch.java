import javafx.scene.layout.Pane;
import javafx.scene.text.*;
import javafx.scene.text.FontWeight;

/**
******************************************************************************
This class is used to pass shared values while switching from window to window
******************************************************************************
*/
public class WindowsSwitch extends Pane {

/**
 *******************************************************************************   
 Create an object for the other classes that represents their respective windows
 *******************************************************************************
 */
    static Menu menu = new Menu();
    static OnePlayerWind onePlayerWind = new OnePlayerWind();
    static TwoPlayerWind twoPlayerWind = new TwoPlayerWind();
    static GameWindow gameWindow = new GameWindow();
    
/**
***********************************************************************************************
This variable indicates whether the game is single-player against a computer-controlled opponent
***********************************************************************************************
*/
    static boolean againstComputer;
   
 /**
 ****************************************************************************
 Show only the window the user has opened and hide the others until necessary 
 ****************************************************************************
 */
    public static void viewPane(Pane pane)
    {
        menu.setVisible(false);
        onePlayerWind.setVisible(false);
        twoPlayerWind.setVisible(false);
        gameWindow.setVisible(false);
        pane.setVisible(true);
    }
   
  }