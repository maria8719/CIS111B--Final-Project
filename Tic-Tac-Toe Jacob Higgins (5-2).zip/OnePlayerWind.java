import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import java.nio.file.Paths;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontPosture;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

/**
**************************************************************
This class creates the window for starting a single-player game
**************************************************************
*/
public class OnePlayerWind extends Pane {

/**
*************************************
Content to be placed inside the window
*************************************
*/
    TextField playerNameTextField = new TextField("Player Name");
    Button startButton = new Button("Start");
    Button backButton = new Button("Back");
    Button exitButton = new Button("Exit");
       
/**
***********************
Create class constructor
************************
*/
         public OnePlayerWind() {
        
/**
******************************
Adjust the size of the content
******************************
*/
        playerNameTextField.setPrefSize(240, 30);
        playerNameTextField.setFont(Font.font("serif", FontWeight.BOLD, FontPosture.ITALIC, 16));
        startButton.setPrefSize(240, 40);
        backButton.setPrefSize(240, 40);
        
/**
***********************************
Adjust the position of the content
***********************************
*/
        playerNameTextField.setTranslateX(80);
        playerNameTextField.setTranslateY(170);
        startButton.setTranslateX(80);
        startButton.setTranslateY(220);
        backButton.setTranslateX(80);
        backButton.setTranslateY(280);
        startButton.setFont(Font.font("serif", FontWeight.BOLD, 17)); 
        backButton.setFont(Font.font("serif", FontWeight.BOLD, 17));
        exitButton.setFont(Font.font("serif", FontWeight.BOLD, 17));
           
/**
******************************
Add the content to the scene
******************************
*/
        getChildren().add(playerNameTextField);
        getChildren().add(startButton);
        getChildren().add(backButton);
        
       
 /**
 **********************************************
 Plays sound while typing the name of the player
 **********************************************
 */
		playerNameTextField.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});

 /**
 ****************************************************
 Define action for when the start button is clicked on
 Action: Begin a single-player game
The name entered by the user is passed and inserted as 
a playerNameTextField variable
*****************************************************
*/
        startButton.setOnAction((event) -> {
            
            PlayMusic.mediaPlayer.stop();
            WindowsSwitch.gameWindow.playerName1.setText(playerNameTextField.getText());
            WindowsSwitch.gameWindow.playerName2.setText("Computer");
            WindowsSwitch.gameWindow.playerScore1.setText("0");
            WindowsSwitch.gameWindow.playerScore2.setText("0");
/**
*******************************************************
Pass a true variable for the boolean that indicates the
player is playing against the computer
*******************************************************
*/
            WindowsSwitch.againstComputer = true;
 /**
 **************************************
 Insert a background image for the board
 ****************************************
 */
  try{
   WindowsSwitch.gameWindow.gameBoardBackground.setImage(new Image(getClass().getResourceAsStream("/images/ticBackground.png")));
     }
  catch(Exception  ex)
{
 System.out.println("ticBackground.png NOT FOUND!");
}

  
          
 /**
 *********************
 Open the game window
 *********************
 */
            WindowsSwitch.viewPane(WindowsSwitch.gameWindow);
        }
        
        );
 /**
 ******************************************************
 Define an action for when the back button is clicked on
 Action: Return to the main menu
 ******************************************************
 */
        backButton.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.menu);
            
        }
        );
        
       }
}