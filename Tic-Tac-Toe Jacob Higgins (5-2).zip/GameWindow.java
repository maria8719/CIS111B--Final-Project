import java.util.Random;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import javafx.scene.text.Font; 
import javafx.scene.text.FontPosture; 
import javafx.scene.text.FontWeight; 

/**
************************************************************************
This class creates the game window that appears when the game is started
in each of the window Multi Player and Single Player. 
************************************************************************
*/

public class GameWindow extends Pane { 

/**
********************************
Create content for the window
********************************
*/
   
    Label playerName1 = new Label();
    Label playerName2 = new Label();
    Label playerScore1 = new Label("0");
    Label playerScore2 = new Label("0");
    Label playerSymbol = new Label();
    Label winner = new Label();
	 GridPane gameBoardPane = new GridPane();
    Button[] gameButtons = new Button[3*3];
    Button back = new Button("Back");
    Button playAgain = new Button("Play Again");
    Button exit = new Button("Exit");
    ImageView gameBoardBackground = new ImageView();
    Random random = new Random();
/**
************************************************************
 This boolean determine when game is over after a player wins
*************************************************************
*/
    boolean gameEnds;
    
/**
***************************************************
 This boolean determine if a tie result has occured
***************************************************
*/
    boolean gameTie; 
    
/**
***************************************
Determine whose turn it is at the moment
***************************************
*/

     boolean player1Turn = true; 
     
/**
*********************************************************************
Count the number of clicks and decide whether or not to stop the game
*********************************************************************
*/
    int OXCounter = 0, number;    
   
/**
*************************************************************
Represents the default colors used for the color icons X and O
**************************************************************
*/
    Color XForeground = Color.YELLOW;
    Color OForeground = Color.GREEN;
/**
**************************************************************
Strings represent the text that display the name of the winner
***************************************************************
*/   
     private String text1, text2;
 /**
 ****************************
 Create the class constructor
 **************************** 
 */
 
     public GameWindow() {
 /**
 **********************
 Adjust size of content
 ***********************
 */
        playerName1.setPrefSize(150, 30);
        playerName2.setPrefSize(150, 30);
        playerScore1.setPrefSize(150, 30);
        playerScore2.setPrefSize(150, 30);
        playerSymbol.setPrefSize(150, 30);
        gameBoardPane.setPrefSize(300, 300);
        playAgain.setPrefSize(140, 30);
         exit.setPrefSize(100, 30);
        //winner.setPrefSize(320, 5);
/**
****************************
Adjust position of content
****************************
*/
        playerName1.setTranslateY(10);
        playerName2.setTranslateX(250);
        playerName2.setTranslateY(10);
        playerScore1.setTranslateY(40);
        playerScore2.setTranslateX(250);
        playerScore2.setTranslateY(40);
        playerSymbol.setTranslateX(120);
        playerSymbol.setTranslateY(25);
        gameBoardBackground.setFitWidth(300);
        gameBoardBackground.setFitHeight(300);
        gameBoardBackground.setTranslateX(45);
        gameBoardBackground.setTranslateY(105);
        gameBoardPane.setTranslateX(45);
        gameBoardPane.setTranslateY(105);
        back.setPrefSize(100, 30);
        back.setTranslateX(20);
        back.setTranslateY(455);
        playAgain.setTranslateX(123);
        playAgain.setTranslateY(455);
        exit.setTranslateX(270);
        exit.setTranslateY(455);
        winner.setTranslateX(40);
		  winner.setTranslateY(420);
       
/**
*************************
Set the font of contents
*************************
*/        
        exit.setFont(Font.font("serif", FontWeight.BOLD, 16)); 
        back.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playAgain.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playerName1.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playerName2.setFont(Font.font("serif", FontWeight.BOLD, 16));
        playerSymbol.setFont(Font.font("serif", FontWeight.BOLD, 16));
        winner.setFont(Font.font("serif", FontWeight.BOLD, 10)); 

/**
*******************************************************
Align text in the center of the space reserved for them
*******************************************************
*/
        playerName1.setAlignment(Pos.CENTER);
        playerName2.setAlignment(Pos.CENTER);
        playerScore1.setAlignment(Pos.CENTER);
        playerScore2.setAlignment(Pos.CENTER);
        playerSymbol.setAlignment(Pos.CENTER);
        

/**
****************************
Create the game board itself
****************************
*/
        gameBoard();
        
/**
****************************
Add content to the container
****************************
*/
        getChildren().add(playerName1);
        getChildren().add(playerName2);
        getChildren().add(playerScore1);
        getChildren().add(playerScore2);
        getChildren().add(playerSymbol);
        getChildren().add(gameBoardPane);
        getChildren().add(gameBoardBackground);
        getChildren().add(back);
        getChildren().add(exit);
        getChildren().add(playAgain);
        getChildren().add(winner);
     
/**
*******************************************
Call the newGame method to begin a new game
********************************************
*/
        newGame();
        
 /**
 *************************************************************************
 Define what happens when you click the back button 
 Action: Return to the previous menu and start a new one or two-player game
***************************************************************************
*/
        back.setOnAction((Event) -> {

            newGame();
            
            if (WindowsSwitch.againstComputer)
                WindowsSwitch.viewPane(WindowsSwitch.onePlayerWind);
            
            else
                WindowsSwitch.viewPane(WindowsSwitch.twoPlayerWind);
            
        });
        
 /**
 **********************************************************
 Define what happens when you click the play again button
 Action: Begin a new game with the same settings
***********************************************************        
*/
        playAgain.setOnAction((Event) -> {
        PlayMusic.playAgainMusic();
            newGame();
        });
        
/**
***************************************************
Define what happens when you click the exit button
Action: Close the program
**************************************************
*/
        
        exit.setOnAction((Action) -> {

            System.exit(0); 
                       
        });
    }
  
/**
**********************************************************************
EventHandler to trigger a buttonClicked event when a button is pressed
**********************************************************************
*/
    EventHandler<ActionEvent> eventHandler = (ActionEvent event) -> {
        buttonClicked(event);
    };

/**
*******************************************************
winnerBackground method color the background of the squares
that the player won with gray color 
*******************************************************

*/    
    private void winnerBackground(Button button1, Button button2, Button button3)
    {
        button1.setStyle("-fx-background-color: Gray;");
        button2.setStyle("-fx-background-color: Gray;");
        button3.setStyle("-fx-background-color: Gray;");
    }
    
 /**
 ***********************************************************
 Create the game board with clickable spaces to place symbols
 ***********************************************************
 */
    private void gameBoard() {
        
        int row = 0;
        int column = 0;
        
        for (int i = 0; i < gameButtons.length; i++) {

            gameButtons[i] = new Button();

            gameButtons[i].setPrefSize(90, 90);
            gameButtons[i].setFocusTraversable(false);

            GridPane.setMargin(gameButtons[i], new Insets(5));
            gameButtons[i].setFont(Font.font("verdana", FontWeight.BOLD, 40));

            gameBoardPane.add(gameButtons[i], column, row);

            gameButtons[i].addEventHandler(ActionEvent.ACTION, e -> {
                buttonClicked(e);
            });
                
            column++;
            if(column == 3)
            {
                row++;
                column = 0;
            }
        }
        
    }
 /**
 *************************************************************************
 Run a check after every move to determine if the game has been won or not
 *************************************************************************
 */
    private void checkIfGameEnds() {
       
    
        String button00 = gameButtons[0].getText();
        String button01 = gameButtons[1].getText();
        String button02 = gameButtons[2].getText();
        String button03 = gameButtons[3].getText();
        String button04 = gameButtons[4].getText();
        String button05 = gameButtons[5].getText();
        String button06=  gameButtons[6].getText();
        String button07 = gameButtons[7].getText();
        String button08 = gameButtons[8].getText();
      
        if (button00.equals(button01) && button00.equals(button02) && !button00.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[0], gameButtons[1], gameButtons[2]);
            PlayMusic.winMusic();
        }
 
        if (button03.equals(button04) && button03.equals(button05) && !button03.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[3], gameButtons[4], gameButtons[5]);
            PlayMusic.winMusic();
        }
 
        if (button06.equals(button07) && button06.equals(button08) && !button06.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[6], gameButtons[7], gameButtons[8]);
            PlayMusic.winMusic();
        }
 
        if (button00.equals(button03) && button00.equals(button06) && !button00.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[0], gameButtons[3], gameButtons[6]);
            PlayMusic.winMusic();
        }
 
        if (button01.equals(button04) && button01.equals(button07) && !button01.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[1], gameButtons[4], gameButtons[7]);
            PlayMusic.winMusic();
        }
 
        if (button02.equals(button05) && button02.equals(button08) && !button02.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[2], gameButtons[5], gameButtons[8]);
            PlayMusic.winMusic();
        }
 
        if (button00.equals(button04) && button00.equals(button08) && !button00.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[0], gameButtons[4], gameButtons[8]);
            PlayMusic.winMusic();
        }
 
        if (button02.equals(button04) && button02.equals(button06) && !button02.equals("")) {
            gameEnds = true;
            winnerBackground(gameButtons[2], gameButtons[4], gameButtons[6]);
            PlayMusic.winMusic();
        }
        
 /** 
 ***********
 Tie game
 **********
 */
          
        if( OXCounter >= 9) 
        {
                        
            gameEnds = true;
            gameTie = true;
            player1Turn = true;
            OXCounter = 0;
           
                    }
/**
*****************************************************
Display a win message for the player that won the game
*****************************************************
*/

        if(gameEnds == true & gameTie == false)        {
            if(player1Turn == true){
                playerScore1.setText(Integer.valueOf(playerScore1.getText()) + 1 + "");
                text1= playerName1.getText() + " WON";
                winner.setText(text1);
                winner.setFont(Font.font("serif", FontWeight.BOLD, 20)); 
                winner.setTextFill(Color.web("#FF0000"));
                // winner.setRotate(20);
                                                
            }else{
                playerScore2.setText(Integer.valueOf(playerScore2.getText()) + 1 + "");
               text2= playerName2.getText() + " WON";
                winner.setText(text2);
                winner.setFont(Font.font("serif", FontWeight.BOLD, 20)); 
                winner.setTextFill(Color.web("#FF0000"));
                 //winner.setRotate(20);
               
               
                }
          }
          else if(gameEnds == true & gameTie == true){
            text3= "GAME OVER";
            winner.setText(text3);
            winner.setFont(Font.font("serif", FontWeight.BOLD, 20)); 
            winner.setTextFill(Color.web("#FF0000")); 
                   
            OXCounter = 0;
            playAgain.requestFocus();
        }
        
    }
/**
**************************************************
Reset the board of Xs and Os when starting a new
 game and determine who goes first next game
**************************************************
*/
    
    private void newGame() {

        gameEnds = false;
        gameTie = false;
        setCurrentSymbol();

        for (Button boardbuttons : gameButtons) {
            boardbuttons.setText("");
            winner.setText("");
            
            boardbuttons.setStyle("-fx-background-color: none; -fx-cursor: hand;");
        }

    }

 /**
 *******************************************************************
 Determine whose turn it is and whose symbol will be placed on click
 *******************************************************************
 */
    private void setCurrentSymbol() {
        
        if (player1Turn == true) {
            playerSymbol.setText("X");
            playerSymbol.setTextFill(XForeground);
        } else {
            playerSymbol.setText("O");
            playerSymbol.setTextFill(OForeground);
        }
        
    }

 /**
 ****************************************************************
 Define what happens when any space on the game board is clicked
 ****************************************************************
 */
    private void buttonClicked(ActionEvent e)
    {
 /**
 *****************************
 Store the clicked space here
 *****************************
 */
       
        Button clickedButton = (Button) e.getSource();
 /**
 ***************************************************************
 On click, place an X or O in the space, but only if the game
 is not yet finished and the space is already empty
 ***************************************************************
 */
        if( gameEnds == false && clickedButton.getText().equals("") )
        {
  /**
  *************************************************************************
  In a two-player game, the current player's symbol is placed in that space
  *************************************************************************
  */
            if(WindowsSwitch.againstComputer == false)
            {
                if(player1Turn) {
                    clickedButton.setTextFill(XForeground);
                    clickedButton.setText("X");
                    PlayMusic.clickMusic();
                }
                else {
                    clickedButton.setTextFill(OForeground);
                    clickedButton.setText("O");
                    PlayMusic.clickMusic();
                }
 /**
 ********************************************************************
 Check if the game has ended. If not, the next player gets their turn
 ********************************************************************
 */
                checkIfGameEnds();
                setCurrentSymbol();
                player1Turn = !player1Turn;
                setCurrentSymbol();
            }
 /**
 ******************************************************
 Check if the game is single-player against the computer
 *******************************************************
 */
            if (WindowsSwitch.againstComputer == true)
            {
 /**
 *********************************************************************
 Add an X to the space clicked on and check if it ends the game or not
 *********************************************************************
 */
                OXCounter++;
                player1Turn = true;
                clickedButton.setTextFill(XForeground);
                clickedButton.setText("X");
                PlayMusic.clickMusic();
                checkIfGameEnds();
 /**
 **********************************************************
 If the game is not over, the computer takes its turn next
 **********************************************************
 */
                if(gameEnds == false)
                {
/**
*************************************************************
Make the spaces temporarily unclickable so the player cannot 
move until the computer takes its turn
*************************************************************
*/
                    for (Button boardButton : gameButtons) {
                        boardButton.removeEventHandler(ActionEvent.ACTION, eventHandler);
                    }
/**
****************************************************
The computer will place an O in a random empty space
****************************************************
*/
                    OXCounter++;
                    player1Turn = false;
                    for (Button boardButton : gameButtons) {
                        number = random.nextInt(9);
                        if (gameButtons[number].getText().equals(""))
                        {
                            gameButtons[number].setTextFill(OForeground);
                            gameButtons[number].setText("O");
                            PlayMusic.clickMusic();
                            break;
                        }
                    }
                    checkIfGameEnds(); 
/**
****************************************************************
Check if the computer's move wins the game. After the computer's 
turn, make the spaces clickable again for the player
****************************************************************
*/
                    for (Button boardButton : gameButtons) {
                        boardButton.addEventHandler(ActionEvent.ACTION, eventHandler);
                    }
                }
            }
    
        } 
    }
    
 	}
   

