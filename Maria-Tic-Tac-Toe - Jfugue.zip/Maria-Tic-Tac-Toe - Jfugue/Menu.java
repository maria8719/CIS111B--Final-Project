import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
***********************************************************************
This class creates the window that first appears when the program starts
***********************************************************************
*/
public class Menu extends Pane {

/**
**************************************
Content to be placed inside the window
**************************************
*/
    Button OnePlayer = new Button("Single Player");
    Button TwoPlayers = new Button("Multi Players");  
    Button playMusic = new Button("Play Music");
    Button exit = new Button("Exit");


/**
**************************
Create the class container
**************************
*/
    public Menu() {
    
/**
*******************************
Adjust the size of the contents
*******************************
*/
        OnePlayer.setPrefSize(240, 40);
        TwoPlayers.setPrefSize(240, 40);
        exit.setPrefSize(240, 40);
        playMusic.setPrefSize(240, 40);
/**
***********************************
Adjust the position of the contents
***********************************
*/
        OnePlayer.setTranslateX(80);
        OnePlayer.setTranslateY(170);
        TwoPlayers.setTranslateX(80);
        TwoPlayers.setTranslateY(230);
        playMusic.setTranslateX(80);
        playMusic.setTranslateY(290);
        exit.setTranslateX(80);
        exit.setTranslateY(350);
                
       OnePlayer.setFont(Font.font("serif", FontWeight.BOLD, 17)); 
       TwoPlayers.setFont(Font.font("serif", FontWeight.BOLD, 17));
       exit.setFont(Font.font("serif", FontWeight.BOLD, 17)); 
       playMusic.setFont(Font.font("serif", FontWeight.BOLD, 17));    
/**
*************************
ADD content to the scene
*************************
*/
        getChildren().add(OnePlayer);
        getChildren().add(TwoPlayers);
        getChildren().add(playMusic);
        getChildren().add(exit);
/**
*********************************************************
Define an action for the OnePlayer button when clicked on
Action: Open to a single-player game
*********************************************************      
*/
        OnePlayer.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.onePlayerWind);
        });
/**
*********************************************************
Define an action for the TwoPlayer button when clicked on
Action: Open to a two-player game
*********************************************************
*/
        TwoPlayers.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.twoPlayerWind);
        });

       
/**
****************************************************
Define an action for the exit button when clicked on
Action: Close the program
****************************************************
*/
        exit.setOnAction((event) -> {
         
            System.exit(0);
            
        });
        
        
        
     playMusic.setOnAction((event) -> {
           PlayMusic.mediaPlayer.stop();
           PlayMusic.music2();
            
        });   
    }
    
 
 
}
