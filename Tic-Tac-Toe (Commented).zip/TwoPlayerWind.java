import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

//This class creates the window for starting a two-player game
public class TwoPlayerWind extends Pane {
      //Content to be placed in the window
    TextField playerName1 = new TextField("player Name (X)");
    TextField playerName2 = new TextField("player Name (O)");
    Button startButton = new Button("Start");
    Button backButton = new Button("Back");
      //Create class container
    public TwoPlayerWind() {

       //Adjust the size of the content
        playerName1.setPrefSize(240, 30);
        playerName2.setPrefSize(240, 30);
        startButton.setPrefSize(240, 40);
        backButton.setPrefSize(240, 40);
      //Adjust the position of the content
        playerName1.setTranslateX(80);
        playerName1.setTranslateY(170);
        playerName2.setTranslateX(80);
        playerName2.setTranslateY(210);
        startButton.setTranslateX(80);
        startButton.setTranslateY(260);
        backButton.setTranslateX(80);
        backButton.setTranslateY(320);
        
        //Add the content to the container
        getChildren().add(playerName1);
        getChildren().add(playerName2);
        getChildren().add(startButton);
        getChildren().add(backButton);
        //Define action for when the start button is clicked on
        //Action: Begin a two-player game
        //The names entered by the user are passed and inserted as playerName1 and playerName2 variables
        startButton.setOnAction((Action) -> {
        PlayMusic.mediaPlayer.stop();
            WindowsSwitch.gameWindow.playerName1.setText(playerName1.getText());
            WindowsSwitch.gameWindow.playerName2.setText(playerName2.getText());
            WindowsSwitch.gameWindow.playerScore1.setText("0");
            WindowsSwitch.gameWindow.playerScore2.setText("0");
            //Pass a false variable for the boolean that indicates the player is not playing against the computer
            WindowsSwitch.againstComputer = false;
            //Insert a background image for the board
           WindowsSwitch.gameWindow.gameBoardBackground
                 .setImage(new Image(getClass().getResourceAsStream("/images/ticBackground.png")));
            //Open the game window
            WindowsSwitch.viewPane(WindowsSwitch.gameWindow);
        });
        //Define an action for when the back button is clicked on
        //Action: Return to the main menu
        backButton.setOnAction((event) -> {
            WindowsSwitch.viewPane(WindowsSwitch.menu);
        });
     
       
      // Plays sound playerName1
		playerName1.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});
 
        
		// Plays sound playerName2
		playerName2.textProperty().addListener(e -> {
			PlayMusic.typekMusic();

		});

    }
    
}
