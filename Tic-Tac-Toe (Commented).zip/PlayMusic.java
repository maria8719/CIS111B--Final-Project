import java.nio.file.Paths;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;

//This class uses MediaPlayer to play music and sound for the game
public class PlayMusic{             

public static MediaPlayer mediaPlayer;
public static MediaPlayer winSound, clickSound, lostSound;

//Play BGM when starting the game
public static void music() {
      		
      Media mainMenuSound = new Media(Paths.get("home.mp3").toUri().toString());
		mediaPlayer = new MediaPlayer(mainMenuSound);
		mediaPlayer.play(); 
        
   }

//Play music for when the player wins the game
public static void winMusic(){

winSound = new MediaPlayer(new Media(Paths.get("win.wav").toUri().toString()));

winSound.play();

}
//Play music for when the player loses to the computer
public static void GameOverMusic(){

lostSound = new MediaPlayer(new Media(Paths.get("gun.mp3").toUri().toString()));


lostSound.play();

}
//Play sound while typing
public static void typekMusic(){
 
 MediaPlayer md = new MediaPlayer(new Media(Paths.get("type.mp3").toUri().toString()));
 
   
       // Plays sound textField1
			md.seek(Duration.ZERO);
			md.play();
		
 
        
		// Plays sound textField2
		md.seek(Duration.ZERO);
		md.play();
}		
//Play sound when clicking mouse
public static void clickMusic(){

clickSound = new MediaPlayer(new Media(Paths.get("click.wav").toUri().toString()));
clickSound.play();



}
}
